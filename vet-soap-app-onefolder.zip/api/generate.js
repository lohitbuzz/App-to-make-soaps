// Vercel Serverless Function: /api/generate
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  try {
    const {
      type, preset, accuracy, asa,
      reason, history, pe, dx, assess, plan, meds,
      ett, ivg, ivsite, fluidsDefault, fluidsDeclined, premeds, induce, intraop, proc, mono, recq, recn, adx, sdx
    } = req.body || {};

    const OPENAI_KEY = process.env.OPENAI_API_KEY;
    const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";
    if(!OPENAI_KEY) return res.status(500).json({error:"Missing OPENAI_API_KEY env var"});

    const sys = `You are GPT-5 Thinking, a veterinary documentation assistant for Dr. Lohit Busanelli. Produce Avimark-compatible SOAPs that strictly follow clinic rules.`;
    const user = `Follow these clinic rules exactly:

Global output rules:
- Subjective: concise case summary only.
- Objective: full PE list (General, Vitals, Eyes, Ears, Oral cavity, Nose, Respiratory, Cardiovascular, Abdomen, Urogenital, Musculoskeletal, Neurological, Integument, Lymphatic, Diagnostics). Data-only description; no interpretations.
- Assessment: problem list + ASA grade for anesthetic/surgical cases; include all interpretations here.
- Plan (categories separated by ONE blank line, in this exact order):
  1. IV Catheter / Fluids
  2. Pre-medications
  3. Induction / Maintenance
  4. Surgical Prep
  5. Surgical Procedure
  6. Intra-op Medications
  7. Recovery
  8. Medications Dispensed
  9. Aftercare
- Include drug concentrations in brackets after every drug name. Midazolam concentration is always [5 mg/ml].
- Do not include administration times.
- Dental extractions: reference “AAHA/AVDC standards” and closure phrase “tension-free flap, no denuded bone, suture line not over defect” with 4-0 Monocryl simple interrupted.
- Local oral nerve blocks when used: lidocaine max 4 mg/kg (dogs) or 2 mg/kg (cats).
- Bloodwork summaries appear only in Objective; interpretations go in Assessment.
- Avimark spacing: single spacing in sections; ONE blank line only between Plan categories.

Privacy rules:
- Do not include owner names, phone numbers, emails, addresses, or microchip numbers. If a microchip was implanted, record a one-line statement “Microchip implanted today.” without the number.

Accuracy Mode: ${accuracy} (Strict=no invention; Medium=fill what you can, blanks for unknowns; Liberal=safe templated normals + “Missing/Assumed” summary).

Case context:
Type: ${type}
Preset: ${preset}
ASA: ${asa||""}

Appointment inputs:
Reason: ${reason||""}
History: ${history||""}
PE (data-only): ${pe||""}
Diagnostics (data-only): ${dx||""}
Assessment notes: ${assess||""}
Plan notes: ${plan||""}
Meds dispensed notes: ${meds||""}

Surgery inputs:
ETT size: ${ett||""}
IV catheter: ${ivg||""}
IV site/side: ${ivsite||""}
Fluids default used (dogs 5 ml/kg/hr; cats 3 ml/kg/hr): ${fluidsDefault||""}
Fluids declined: ${fluidsDeclined||""}
Premedications: ${premeds||""}
Induction/Maintenance: ${induce||""}
Intra-op meds: ${intraop||""}
Procedure notes: ${proc||""}
Monocryl override: ${mono||""}
Recovery quality: ${recq||""}
Recovery notes: ${recn||""}
Anesthesia duration: ${adx||""}
Surgery duration: ${sdx||""}

Output:
1) Produce a complete SOAP conforming exactly to the above rules and formatting. Never invent vitals in Strict/Medium.
2) If any required inputs are missing, still output a SOAP and add one line at the end: “Missing/Assumed: <short list>”.
3) Return TWO versions with clear delimiters:
===AVIMARK_COPY===
...soap here...
===CLINIC_SAFE_COPY===
...soap here...`;

    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {role:"system", content: sys},
          {role:"user", content: user}
        ],
        temperature: 0.2
      })
    });
    if(!r.ok){
      const text = await r.text();
      return res.status(500).json({error:"OpenAI error", detail:text});
    }
    const data = await r.json();
    const content = data.choices?.[0]?.message?.content || "";

    const av = content.split("===CLINIC_SAFE_COPY===")[0]?.split("===AVIMARK_COPY===")[1]?.trim() || content.trim();
    let cs = content.split("===CLINIC_SAFE_COPY===")[1]?.trim() || av;

    function maskClinicSafe(text){
      let t = text;
      t = t.replace(/\b\d{15,}\b/g, "[MICROCHIP REDACTED]");
      const kw = /(microchip|mchip|chip|AVID|HomeAgain)/i;
      t = t.split("\n").map(line=>{
        if(kw.test(line)) return line.replace(/\b\d{9,10}\b/g, "[ID REDACTED]");
        return line;
      }).join("\n");
      return t;
    }
    cs = maskClinicSafe(cs);

    res.status(200).json({avimark: av, clinicSafe: cs});
  } catch (e) {
    console.error(e);
    res.status(500).json({error:'Server error'});
  }
}
