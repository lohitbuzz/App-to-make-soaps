# Vet SOAP App v1.0 — One-Folder Deploy

This is a **single-folder app** you can paste into a host like **Vercel** and go live.  
- Mobile-first, works great on iPhone.  
- Minimal inputs → **Avimark-clean SOAP** using your clinic rules.  
- **No client-side keys.** Serverless function calls OpenAI securely.  
- **On-device cases** with 24h auto-close (localStorage).  
- Privacy helpers: Clinic-Safe copy masks microchip-like numbers.

## Quick Deploy (Vercel)
1) Create a Vercel account → “New Project” → **Import** this folder (upload or connect GitHub).  
2) In **Settings → Environment Variables** add:
   - `OPENAI_API_KEY = sk-...`
   - *(optional)* `OPENAI_MODEL = gpt-4o-mini`
3) Deploy. Your app is live at https://your-project.vercel.app  
4) On iPhone → Share → **Add to Home Screen** for an app-like icon.

## Files
- `/index.html` — the entire UI (Appointment vs Surgery, accuracy modes, etc.).  
- `/api/generate.js` — serverless function calling OpenAI Chat Completions with your precise prompt and rules.

## Notes
- We don’t store data server-side. The generated outputs exist only in your browser.  
- “Clinic-Safe” copy masks 15+ digit runs and 9–10 digits near microchip keywords.  
- Midazolam hard rule: **[5 mg/ml]** everywhere.  
- Avimark spacing: single inside sections; **one blank line** between Plan categories.

## Next steps (optional)
- Add file upload + Vision parsing to `/api/generate` later.  
- Move local cases to a real DB if you want shared case lists.
